package com.techelevator;

import org.junit.Assert;
import org.junit.Test;

public class HelloControllerTest {
	
	@Test
	public void a_silly_test_that_always_passes() {
		Assert.assertEquals(2, 2);
	}
}